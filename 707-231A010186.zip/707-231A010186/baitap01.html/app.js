const products = [
  { id: 1, name: "Chuột không dây Logitech", price: 250000, category: "Phụ kiện" },
  { id: 2, name: "Bàn phím cơ RGB", price: 1500000, category: "Phụ kiện" },
  { id: 3, name: "Màn hình 24 inch Full HD", price: 3200000, category: "Màn hình" },
  { id: 4, name: "Laptop Dell Inspiron", price: 15000000, category: "Laptop" },
  { id: 5, name: "Tai nghe gaming", price: 750000, category: "Âm thanh" },
  { id: 6, name: "Ổ cứng SSD 500GB", price: 1200000, category: "Lưu trữ" }
];

products.forEach(p => {
  p.nameLower = p.name.toLowerCase();
});

const productListEl = document.getElementById("productList");
const messageEl = document.getElementById("message");
const searchInput = document.getElementById("searchInput");
const searchBtn = document.getElementById("searchBtn");

function formatPrice(price) {
  return price.toLocaleString("vi-VN") + " đ";
}

function renderProducts(list) {
  productListEl.innerHTML = "";

  list.forEach(product => {
    const card = document.createElement("div");
    card.className = "product-card";

    const nameEl = document.createElement("div");
    nameEl.className = "product-name";
    nameEl.textContent = product.name;

    const priceEl = document.createElement("div");
    priceEl.className = "product-price";
    priceEl.textContent = formatPrice(product.price);

    const categoryEl = document.createElement("div");
    categoryEl.className = "product-category";
    categoryEl.textContent = "Loại: " + product.category;

    card.appendChild(nameEl);
    card.appendChild(priceEl);
    card.appendChild(categoryEl);

    productListEl.appendChild(card);
  });
}

renderProducts(products);

function handleSearch() {
  const rawQuery = searchInput.value;
  const query = rawQuery.trim().toLowerCase();

  messageEl.textContent = "";

  if (query === "") {
    renderProducts(products);
    return;
  }

  const filtered = products.filter(p => p.nameLower.includes(query));

  if (filtered.length === 0) {
    renderProducts([]);
    messageEl.textContent = "Không tìm thấy sản phẩm phù hợp.";
  } else {
    renderProducts(filtered);
  }
}

searchBtn.addEventListener("click", handleSearch);

searchInput.addEventListener("keydown", function (e) {
  if (e.key === "Enter") {
    handleSearch();
  }
});
