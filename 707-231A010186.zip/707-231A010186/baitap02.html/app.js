const form = document.getElementById("registerForm");
const messageEl = document.getElementById("message");

form.addEventListener("submit", function (e) {
  e.preventDefault();

  const name = document.getElementById("name").value.trim();
  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value;
  const agree = document.getElementById("agree").checked;

  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  const passPattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/;

  if (name === "" || email === "" || password === "") {
    showMessage("Vui lòng nhập đầy đủ thông tin", "red");
    return;
  }

  if (!emailPattern.test(email)) {
    showMessage("Email không hợp lệ", "red");
    return;
  }

  if (!passPattern.test(password)) {
    showMessage("Mật khẩu phải ≥ 8 ký tự và có chữ hoa/thường/số", "red");
    return;
  }

  if (!agree) {
    showMessage("Bạn phải đồng ý điều khoản", "red");
    return;
  }

  const userData = { name, email, password };
  localStorage.setItem("user", JSON.stringify(userData));

  showMessage("Đăng ký thành công!", "green");

  form.reset();
});

function showMessage(msg, color) {
  messageEl.textContent = msg;
  messageEl.style.color = color;
}
