let totalTime = 6 * 100;
let interval = null;

function startCountdown() {

    interval = setInterval(() => {

        totalTime--;

        let minutes = Math.floor(totalTime / 60);
        let seconds = totalTime % 60;

        document.getElementById("timer").textContent =
            `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;

        if (totalTime <= 60) {
            document.getElementById("timer").classList.add("warning");
        }

        if (totalTime <= 0) {
            clearInterval(interval);
            showModal();
        }

    }, 1000);
}

function showModal() {
    document.getElementById("modal").style.display = "flex";
}

document.getElementById("closeBtn").addEventListener("click", () => {
    document.getElementById("modal").style.display = "none";
});

startCountdown();
